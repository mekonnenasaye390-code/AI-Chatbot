#!/bin/bash
# Run from project root: bash start_backend.sh

cd backend

echo "Installing dependencies..."
pip install -r requirements.txt

echo ""
echo "Starting FastAPI backend on http://localhost:8000"
echo "Make sure ANTHROPIC_API_KEY is set!"
echo ""

export ANTHROPIC_API_KEY="${ANTHROPIC_API_KEY:-YOUR_KEY_HERE}"

uvicorn main:app --host 0.0.0.0 --port 8000 --reload
